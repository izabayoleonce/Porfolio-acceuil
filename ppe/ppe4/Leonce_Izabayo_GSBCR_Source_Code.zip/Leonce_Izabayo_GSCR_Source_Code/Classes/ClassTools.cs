﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSBCR.Classes
{
    public class Tools
    {
        public static Models.User CurrentUser = null;
    }
}
