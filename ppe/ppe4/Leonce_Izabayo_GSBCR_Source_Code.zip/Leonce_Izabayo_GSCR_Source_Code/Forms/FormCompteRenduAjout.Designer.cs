﻿
namespace GSBCR.Forms
{
    partial class FormCompteRenduAjout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.cboPraticien = new System.Windows.Forms.ComboBox();
            this.txtCoefficient = new System.Windows.Forms.TextBox();
            this.btnValidate = new System.Windows.Forms.Button();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtBilan = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.checkDocumentation = new System.Windows.Forms.CheckBox();
            this.cboProduit1 = new System.Windows.Forms.ComboBox();
            this.cboProduit2 = new System.Windows.Forms.ComboBox();
            this.cboMotif = new System.Windows.Forms.ComboBox();
            this.dtpDateVisite = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(219, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Rapport de visite";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Date visite  :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "Praticien  :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 114);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 17);
            this.label5.TabIndex = 6;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(20, 156);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 17);
            this.label9.TabIndex = 10;
            this.label9.Text = "Coefficient  :";
            // 
            // cboPraticien
            // 
            this.cboPraticien.DisplayMember = "Uid";
            this.cboPraticien.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPraticien.FormattingEnabled = true;
            this.cboPraticien.Location = new System.Drawing.Point(172, 120);
            this.cboPraticien.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboPraticien.Name = "cboPraticien";
            this.cboPraticien.Size = new System.Drawing.Size(251, 24);
            this.cboPraticien.TabIndex = 1;
            this.cboPraticien.ValueMember = "Uid";
            // 
            // txtCoefficient
            // 
            this.txtCoefficient.Location = new System.Drawing.Point(172, 154);
            this.txtCoefficient.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCoefficient.Name = "txtCoefficient";
            this.txtCoefficient.Size = new System.Drawing.Size(107, 22);
            this.txtCoefficient.TabIndex = 2;
            // 
            // btnValidate
            // 
            this.btnValidate.Location = new System.Drawing.Point(269, 474);
            this.btnValidate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnValidate.Name = "btnValidate";
            this.btnValidate.Size = new System.Drawing.Size(80, 36);
            this.btnValidate.TabIndex = 1001;
            this.btnValidate.Text = "Valider";
            this.btnValidate.UseVisualStyleBackColor = true;
            this.btnValidate.Click += new System.EventHandler(this.BtnValidate_Click);
            // 
            // btn_cancel
            // 
            this.btn_cancel.Location = new System.Drawing.Point(355, 474);
            this.btn_cancel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(80, 36);
            this.btn_cancel.TabIndex = 1000;
            this.btn_cancel.Text = "Annuler";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new System.EventHandler(this.Btn_cancel_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(21, 227);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(51, 17);
            this.label10.TabIndex = 11;
            this.label10.Text = "Bilan  :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(19, 398);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(141, 17);
            this.label11.TabIndex = 12;
            this.label11.Text = "DOCUMENTATION  :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(20, 322);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(94, 17);
            this.label12.TabIndex = 13;
            this.label12.Text = "PRODUIT 1  :";
            // 
            // txtBilan
            // 
            this.txtBilan.Location = new System.Drawing.Point(172, 225);
            this.txtBilan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtBilan.MaxLength = 100;
            this.txtBilan.Name = "txtBilan";
            this.txtBilan.Size = new System.Drawing.Size(251, 22);
            this.txtBilan.TabIndex = 4;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(206, 269);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(133, 17);
            this.label14.TabIndex = 15;
            this.label14.Text = "Eléments présentés";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(21, 194);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(50, 17);
            this.label15.TabIndex = 16;
            this.label15.Text = "Motif  :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 358);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(94, 17);
            this.label7.TabIndex = 18;
            this.label7.Text = "PRODUIT 2  :";
            // 
            // checkDocumentation
            // 
            this.checkDocumentation.AutoSize = true;
            this.checkDocumentation.Location = new System.Drawing.Point(172, 399);
            this.checkDocumentation.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkDocumentation.Name = "checkDocumentation";
            this.checkDocumentation.Size = new System.Drawing.Size(18, 17);
            this.checkDocumentation.TabIndex = 7;
            this.checkDocumentation.UseVisualStyleBackColor = true;
            // 
            // cboProduit1
            // 
            this.cboProduit1.DisplayMember = "Uid";
            this.cboProduit1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboProduit1.FormattingEnabled = true;
            this.cboProduit1.Location = new System.Drawing.Point(172, 320);
            this.cboProduit1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboProduit1.Name = "cboProduit1";
            this.cboProduit1.Size = new System.Drawing.Size(225, 24);
            this.cboProduit1.TabIndex = 5;
            this.cboProduit1.ValueMember = "Uid";
            // 
            // cboProduit2
            // 
            this.cboProduit2.DisplayMember = "Uid";
            this.cboProduit2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboProduit2.FormattingEnabled = true;
            this.cboProduit2.Location = new System.Drawing.Point(172, 358);
            this.cboProduit2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboProduit2.Name = "cboProduit2";
            this.cboProduit2.Size = new System.Drawing.Size(225, 24);
            this.cboProduit2.TabIndex = 6;
            this.cboProduit2.ValueMember = "Uid";
            // 
            // cboMotif
            // 
            this.cboMotif.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMotif.FormattingEnabled = true;
            this.cboMotif.Items.AddRange(new object[] {
            "Test motif"});
            this.cboMotif.Location = new System.Drawing.Point(172, 192);
            this.cboMotif.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboMotif.Name = "cboMotif";
            this.cboMotif.Size = new System.Drawing.Size(251, 24);
            this.cboMotif.TabIndex = 3;
            // 
            // dtpDateVisite
            // 
            this.dtpDateVisite.Location = new System.Drawing.Point(172, 86);
            this.dtpDateVisite.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtpDateVisite.Name = "dtpDateVisite";
            this.dtpDateVisite.Size = new System.Drawing.Size(178, 22);
            this.dtpDateVisite.TabIndex = 0;
            // 
            // FormCompteRenduAjout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(575, 526);
            this.Controls.Add(this.dtpDateVisite);
            this.Controls.Add(this.cboMotif);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btnValidate);
            this.Controls.Add(this.txtBilan);
            this.Controls.Add(this.txtCoefficient);
            this.Controls.Add(this.cboPraticien);
            this.Controls.Add(this.cboProduit2);
            this.Controls.Add(this.cboProduit1);
            this.Controls.Add(this.checkDocumentation);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormCompteRenduAjout";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.FormRapportAjout_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cboPraticien;
        private System.Windows.Forms.TextBox txtCoefficient;
        private System.Windows.Forms.Button btnValidate;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtBilan;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox checkDocumentation;
        private System.Windows.Forms.ComboBox cboProduit1;
        private System.Windows.Forms.ComboBox cboProduit2;
        private System.Windows.Forms.ComboBox cboMotif;
        private System.Windows.Forms.DateTimePicker dtpDateVisite;
    }
}