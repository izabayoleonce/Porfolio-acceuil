﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSBCR.Forms
{
    public partial class FormCompteRenduAjout : Form
    {
        int iMotif = 0;

        public FormCompteRenduAjout()
        {
            InitializeComponent();

        }

        private void FormRapportAjout_Load(object sender, EventArgs e)
        {
            Datas.DataSetCompteRenduTableAdapters.tbPraticienTableAdapter praticienTableAdapter = new Datas.DataSetCompteRenduTableAdapters.tbPraticienTableAdapter() { Connection = new SqlConnection(Classes.Security.ConnectionString) };
            Datas.DataSetMedicamentTableAdapters.tbMedicamentTableAdapter medicamentTableAdapter = new Datas.DataSetMedicamentTableAdapters.tbMedicamentTableAdapter() { Connection = new SqlConnection(Classes.Security.ConnectionString) };

            this.cboPraticien.DataSource = praticienTableAdapter.GetData();
            this.cboPraticien.DisplayMember = "Nom";
            this.cboPraticien.ValueMember = "Uid";

            this.cboProduit1.DataSource = medicamentTableAdapter.GetData();
            this.cboProduit1.DisplayMember = "NomCommercial";
            this.cboProduit1.ValueMember = "Uid";

            this.cboProduit2.DataSource = medicamentTableAdapter.GetData();
            this.cboProduit2.DisplayMember = "NomCommercial";
            this.cboProduit2.ValueMember = "Uid";
        }

        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnValidate_Click(object sender, EventArgs e)
        {
            int res = 0;
            SqlConnection connection = new SqlConnection(Classes.Security.ConnectionString);
            try
            {
                connection.Open();
                try
                {
                    SqlCommand cmd = new SqlCommand("INSERT INTO tbCompteRendu  (" +
                                  "DateVisite" +
                                  ",UidPracticien" +
                                  ",Practicien" +
                                  ",Coefficient" +
                                  ",MotifIdfc" +
                                  ",MotifAutre" +
                                  ",Bilan" +
                                  ",UidProduit1" +
                                  ",UidProduit2" +
                                  ",Documentation" +
                                  ") VALUES (" +
                                  "@DateVisite" +
                                  ",@UidPraticien" +
                                  ",@Praticien" +
                                  ",@Coefficient" +
                                  ",@MotifIdfc" +
                                  ",@MotifAutre" +
                                  ",@Bilan" +
                                  ",@UidProduit1" +
                                  ",@UidProduit2" +
                                  ",@Documentation)", connection);

                    //On ajoute un paramètre SQL à la commande
                    cmd.Parameters.Add(new SqlParameter("@DateVisite", this.dtpDateVisite.Value));
                    //On ajoute un paramètre SQL à la commande
                    cmd.Parameters.Add(new SqlParameter("@UidPraticien", this.cboPraticien.SelectedValue));
                    //On ajoute un paramètre SQL à la commande
                    cmd.Parameters.Add(new SqlParameter("@Praticien", this.cboPraticien.Text));
                    //On ajoute un paramètre SQL à la commande
                    cmd.Parameters.Add(new SqlParameter("@Coefficient", this.txtCoefficient.Text.Replace(',', '.')));
                    //On ajoute un paramètre SQL à la commande
                    cmd.Parameters.Add(new SqlParameter("@MotifIdfc", iMotif));
                    //On ajoute un paramètre SQL à la commande
                    cmd.Parameters.Add(new SqlParameter("@MotifAutre", this.cboMotif.Text));
                    //On ajoute un paramètre SQL à la commande
                    cmd.Parameters.Add(new SqlParameter("@Bilan", this.txtBilan.Text));
                    //On ajoute un paramètre SQL à la commande
                    cmd.Parameters.Add(new SqlParameter("@UidProduit1", this.cboProduit1.SelectedValue));
                    //On ajoute un paramètre SQL à la commande
                    cmd.Parameters.Add(new SqlParameter("@UidProduit2", this.cboProduit2.SelectedValue));
                    //On ajoute un paramètre SQL à la commande
                    cmd.Parameters.Add(new SqlParameter("@Documentation", this.checkDocumentation.Checked));
                    //On initialise la variable de résultat avec le retour de l'execution de la commande
                    res = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine(ex.Message);
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
            if (res > 0) { this.Close(); }
            else { MessageBox.Show("Echec de l'enregistrement.", "GSB", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

    }
}
