﻿
namespace GSBCR.Forms
{
    partial class FormVisiteurListe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormVisiteurListe));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgvListCol = new System.Windows.Forms.DataGridView();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btnRefresh = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btnAjouter = new System.Windows.Forms.ToolStripButton();
            this.dgvColMatricule = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvColDateEmbauche = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvColNom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvColPrenom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvColAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvColCodePostal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvColVille = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvColLaboratoir = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvColSecteur = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListCol)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvListCol
            // 
            this.dgvListCol.AllowUserToAddRows = false;
            this.dgvListCol.AllowUserToDeleteRows = false;
            this.dgvListCol.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListCol.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgvColMatricule,
            this.dgvColDateEmbauche,
            this.dgvColNom,
            this.dgvColPrenom,
            this.dgvColAddress,
            this.dgvColCodePostal,
            this.dgvColVille,
            this.dgvColLaboratoir,
            this.dgvColSecteur});
            this.dgvListCol.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvListCol.Location = new System.Drawing.Point(0, 27);
            this.dgvListCol.Margin = new System.Windows.Forms.Padding(4);
            this.dgvListCol.Name = "dgvListCol";
            this.dgvListCol.ReadOnly = true;
            this.dgvListCol.RowHeadersWidth = 51;
            this.dgvListCol.Size = new System.Drawing.Size(1067, 527);
            this.dgvListCol.TabIndex = 5;
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnRefresh,
            this.toolStripSeparator1,
            this.btnAjouter});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1067, 27);
            this.toolStrip1.TabIndex = 4;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btnRefresh
            // 
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(72, 24);
            this.btnRefresh.Text = "Rafraîchir";
            this.btnRefresh.Click += new System.EventHandler(this.BtnRefresh_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // btnAjouter
            // 
            this.btnAjouter.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnAjouter.Image = ((System.Drawing.Image)(resources.GetObject("btnAjouter.Image")));
            this.btnAjouter.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAjouter.Name = "btnAjouter";
            this.btnAjouter.Size = new System.Drawing.Size(62, 24);
            this.btnAjouter.Text = "Ajouter";
            this.btnAjouter.Click += new System.EventHandler(this.BtnAjouter_Click);
            // 
            // dgvColMatricule
            // 
            this.dgvColMatricule.DataPropertyName = "Matricule";
            this.dgvColMatricule.HeaderText = "Matricule";
            this.dgvColMatricule.MinimumWidth = 6;
            this.dgvColMatricule.Name = "dgvColMatricule";
            this.dgvColMatricule.ReadOnly = true;
            this.dgvColMatricule.Width = 125;
            // 
            // dgvColDateEmbauche
            // 
            this.dgvColDateEmbauche.DataPropertyName = "DateEmbauche";
            dataGridViewCellStyle1.Format = "d";
            dataGridViewCellStyle1.NullValue = null;
            this.dgvColDateEmbauche.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgvColDateEmbauche.HeaderText = "DateEmbauche";
            this.dgvColDateEmbauche.MinimumWidth = 6;
            this.dgvColDateEmbauche.Name = "dgvColDateEmbauche";
            this.dgvColDateEmbauche.ReadOnly = true;
            this.dgvColDateEmbauche.Width = 125;
            // 
            // dgvColNom
            // 
            this.dgvColNom.DataPropertyName = "Nom";
            this.dgvColNom.HeaderText = "Nom";
            this.dgvColNom.MinimumWidth = 6;
            this.dgvColNom.Name = "dgvColNom";
            this.dgvColNom.ReadOnly = true;
            this.dgvColNom.Width = 125;
            // 
            // dgvColPrenom
            // 
            this.dgvColPrenom.DataPropertyName = "Prenom";
            this.dgvColPrenom.HeaderText = "Prénom";
            this.dgvColPrenom.MinimumWidth = 6;
            this.dgvColPrenom.Name = "dgvColPrenom";
            this.dgvColPrenom.ReadOnly = true;
            this.dgvColPrenom.Width = 125;
            // 
            // dgvColAddress
            // 
            this.dgvColAddress.DataPropertyName = "Adresse";
            this.dgvColAddress.HeaderText = "Address";
            this.dgvColAddress.MinimumWidth = 6;
            this.dgvColAddress.Name = "dgvColAddress";
            this.dgvColAddress.ReadOnly = true;
            this.dgvColAddress.Width = 125;
            // 
            // dgvColCodePostal
            // 
            this.dgvColCodePostal.DataPropertyName = "CodePostal";
            this.dgvColCodePostal.HeaderText = "Cp";
            this.dgvColCodePostal.MinimumWidth = 6;
            this.dgvColCodePostal.Name = "dgvColCodePostal";
            this.dgvColCodePostal.ReadOnly = true;
            this.dgvColCodePostal.Width = 125;
            // 
            // dgvColVille
            // 
            this.dgvColVille.DataPropertyName = "Ville";
            this.dgvColVille.HeaderText = "Ville";
            this.dgvColVille.MinimumWidth = 6;
            this.dgvColVille.Name = "dgvColVille";
            this.dgvColVille.ReadOnly = true;
            this.dgvColVille.Width = 125;
            // 
            // dgvColLaboratoir
            // 
            this.dgvColLaboratoir.DataPropertyName = "Laboratoire";
            this.dgvColLaboratoir.HeaderText = "Laboratoir";
            this.dgvColLaboratoir.MinimumWidth = 6;
            this.dgvColLaboratoir.Name = "dgvColLaboratoir";
            this.dgvColLaboratoir.ReadOnly = true;
            this.dgvColLaboratoir.Width = 125;
            // 
            // dgvColSecteur
            // 
            this.dgvColSecteur.DataPropertyName = "Secteur";
            this.dgvColSecteur.HeaderText = "Secteur";
            this.dgvColSecteur.MinimumWidth = 6;
            this.dgvColSecteur.Name = "dgvColSecteur";
            this.dgvColSecteur.ReadOnly = true;
            this.dgvColSecteur.Width = 125;
            // 
            // FormVisiteurListe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.dgvListCol);
            this.Controls.Add(this.toolStrip1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormVisiteurListe";
            this.Text = "Visiteur Liste";
            ((System.ComponentModel.ISupportInitialize)(this.dgvListCol)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dgvListCol;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel btnRefresh;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btnAjouter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColMatricule;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColDateEmbauche;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColNom;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColPrenom;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColCodePostal;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColVille;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColLaboratoir;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColSecteur;
    }
}