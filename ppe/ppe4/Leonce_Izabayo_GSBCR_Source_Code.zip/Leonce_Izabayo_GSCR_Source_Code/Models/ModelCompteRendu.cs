﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSBCR.Models
{
    public class CompteRendu
    {
        public Guid Uid { get; set; }
        public int Numero { get; set; }
        public DateTime DateVisite { get; set; }
        public Guid UidPracticien { get; set; }
        public string Practicien { get; set; }
        public double Coefficient { get; set; }
        public int MotifIdfc { get; set; }
        public string MotifAutre { get; set; }
        public string Bilan { get; set; }
        public string UidProduit1 { get; set; }
        public string UidProduit2 { get; set; }
        public bool Documentation { get; set; }
    }
}
