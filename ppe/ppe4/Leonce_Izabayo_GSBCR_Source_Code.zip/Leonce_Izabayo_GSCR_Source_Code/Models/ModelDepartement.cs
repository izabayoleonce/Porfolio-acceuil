﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSBCR.Models
{
    public class Departement
    {
        public string Code { get; set; }
        public string Nom { get; set; }
    }

    public class Departements
    {
        public static List<Departement> GetDepartements()
        {
            List<Departement> lst = new List<Departement>()
            {
                new Departement() { Code = "01", Nom = "Ain" },
                new Departement() { Code = "02", Nom = "Aisne" },
                new Departement() { Code = "03", Nom = "Allier" },
                new Departement() { Code = "04", Nom = "Alpes-de-Haute-Provence" },
                new Departement() { Code = "05", Nom = "Hautes-alpes" },
                new Departement() { Code = "06", Nom = "Alpes-maritimes" },
                new Departement() { Code = "07", Nom = "Ardèche" },
                new Departement() { Code = "08", Nom = "Ardennes" },
                new Departement() { Code = "09", Nom = "Ariège" },
                new Departement() { Code = "10", Nom = "Aube" },
                new Departement() { Code = "11", Nom = "Aude" },
                new Departement() { Code = "12", Nom = "Aveyron" },
                new Departement() { Code = "13", Nom = "Bouches-du-Rhône" },
                new Departement() { Code = "14", Nom = "Calvados" },
                new Departement() { Code = "15", Nom = "Cantal" },
                new Departement() { Code = "16", Nom = "Charente" },
                new Departement() { Code = "17", Nom = "Charente-maritime" },
                new Departement() { Code = "18", Nom = "Cher" },
                new Departement() { Code = "19", Nom = "Corrèze" },
                new Departement() { Code = "2a", Nom = "Corse-du-sud" },
                new Departement() { Code = "2b", Nom = "Haute-Corse" },
                new Departement() { Code = "21", Nom = "Côte-d'Or" },
                new Departement() { Code = "22", Nom = "Côtes-d'Armor" },
                new Departement() { Code = "23", Nom = "Creuse" },
                new Departement() { Code = "24", Nom = "Dordogne" },
                new Departement() { Code = "25", Nom = "Doubs" },
                new Departement() { Code = "26", Nom = "Drôme" },
                new Departement() { Code = "27", Nom = "Eure" },
                new Departement() { Code = "28", Nom = "Eure-et-loir" },
                new Departement() { Code = "29", Nom = "Finistère" },
                new Departement() { Code = "30", Nom = "Gard" },
                new Departement() { Code = "31", Nom = "Haute-garonne" },
                new Departement() { Code = "32", Nom = "Gers" },
                new Departement() { Code = "33", Nom = "Gironde" },
                new Departement() { Code = "34", Nom = "Hérault" },
                new Departement() { Code = "35", Nom = "Ille-et-vilaine" },
                new Departement() { Code = "36", Nom = "Indre" },
                new Departement() { Code = "37", Nom = "Indre-et-loire" },
                new Departement() { Code = "38", Nom = "Isère" },
                new Departement() { Code = "39", Nom = "Jura" },
                new Departement() { Code = "40", Nom = "Landes" },
                new Departement() { Code = "41", Nom = "Loir-et-cher" },
                new Departement() { Code = "42", Nom = "Loire" },
                new Departement() { Code = "43", Nom = "Haute-loire" },
                new Departement() { Code = "44", Nom = "Loire-atlantique" },
                new Departement() { Code = "45", Nom = "Loiret" },
                new Departement() { Code = "46", Nom = "Lot" },
                new Departement() { Code = "47", Nom = "Lot-et-garonne" },
                new Departement() { Code = "48", Nom = "Lozère" },
                new Departement() { Code = "49", Nom = "Maine-et-loire" },
                new Departement() { Code = "50", Nom = "Manche" },
                new Departement() { Code = "51", Nom = "Marne" },
                new Departement() { Code = "52", Nom = "Haute-marne" },
                new Departement() { Code = "53", Nom = "Mayenne" },
                new Departement() { Code = "54", Nom = "Meurthe-et-moselle" },
                new Departement() { Code = "55", Nom = "Meuse" },
                new Departement() { Code = "56", Nom = "Morbihan" },
                new Departement() { Code = "57", Nom = "Moselle" },
                new Departement() { Code = "58", Nom = "Nièvre" },
                new Departement() { Code = "59", Nom = "Nord" },
                new Departement() { Code = "60", Nom = "Oise" },
                new Departement() { Code = "61", Nom = "Orne" },
                new Departement() { Code = "62", Nom = "Pas-de-calais" },
                new Departement() { Code = "63", Nom = "Puy-de-dôme" },
                new Departement() { Code = "64", Nom = "Pyrénées-atlantiques" },
                new Departement() { Code = "65", Nom = "Hautes-Pyrénées" },
                new Departement() { Code = "66", Nom = "Pyrénées-orientales" },
                new Departement() { Code = "67", Nom = "Bas-rhin" },
                new Departement() { Code = "68", Nom = "Haut-rhin" },
                new Departement() { Code = "69", Nom = "Rhône" },
                new Departement() { Code = "70", Nom = "Haute-saône" },
                new Departement() { Code = "71", Nom = "Saône-et-loire" },
                new Departement() { Code = "72", Nom = "Sarthe" },
                new Departement() { Code = "73", Nom = "Savoie" },
                new Departement() { Code = "74", Nom = "Haute-savoie" },
                new Departement() { Code = "75", Nom = "Paris" },
                new Departement() { Code = "76", Nom = "Seine-maritime" },
                new Departement() { Code = "77", Nom = "Seine-et-marne" },
                new Departement() { Code = "78", Nom = "Yvelines" },
                new Departement() { Code = "79", Nom = "Deux-sèvres" },
                new Departement() { Code = "80", Nom = "Somme" },
                new Departement() { Code = "81", Nom = "Tarn" },
                new Departement() { Code = "82", Nom = "Tarn-et-garonne" },
                new Departement() { Code = "83", Nom = "Var" },
                new Departement() { Code = "84", Nom = "Vaucluse" },
                new Departement() { Code = "85", Nom = "Vendée" },
                new Departement() { Code = "86", Nom = "Vienne" },
                new Departement() { Code = "87", Nom = "Haute-vienne" },
                new Departement() { Code = "88", Nom = "Vosges" },
                new Departement() { Code = "89", Nom = "Yonne" },
                new Departement() { Code = "90", Nom = "Territoire de belfort" },
                new Departement() { Code = "91", Nom = "Essonne" },
                new Departement() { Code = "92", Nom = "Hauts-de-seine" },
                new Departement() { Code = "93", Nom = "Seine-Saint-Denis" },
                new Departement() { Code = "94", Nom = "Val-de-marne" },
                new Departement() { Code = "95", Nom = "Val-d'oise" },
                new Departement() { Code = "971", Nom = "Guadeloupe" },
                new Departement() { Code = "972", Nom = "Martinique" },
                new Departement() { Code = "973", Nom = "Guyane" },
                new Departement() { Code = "974", Nom = "La réunion" },
                new Departement() { Code = "976", Nom = "Mayotte" }
            };
            return lst;
        }

    }
}






