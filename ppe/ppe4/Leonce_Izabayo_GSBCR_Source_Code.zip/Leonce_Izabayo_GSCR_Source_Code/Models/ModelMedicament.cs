﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSBCR.Models
{
    public class FamilleMedicament
    {
        public Guid Uid { get; set; }
        public string Code { get; set; }
        public string Libelle { get; set; }
    }
    public class Medicament
    {
        public Guid Uid { get; set; }
        public string DepotLegal { get; set; }
        public string NomCommercial { get; set; }
        public string Famille { get; set; }
        public string Effet { get; set; }
        public string Composition { get; set; }
        public string ContreIndication { get; set; }
        public double PrixEchantillion { get; set; }
    }
}
