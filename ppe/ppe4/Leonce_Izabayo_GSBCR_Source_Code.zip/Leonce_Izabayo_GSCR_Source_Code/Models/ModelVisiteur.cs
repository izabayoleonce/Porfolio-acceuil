﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSBCR.Models
{
    public class Visiteur
    {
        public Guid Uid { get; set; }
        public string Matricule { get; set; }
        public string Departement { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public string Adresse { get; set; }
        public string CodePostal { get; set; }
        public string Ville { get; set; }
        public DateTime DateEmbauche { get; set; }
        public string Secteur { get; set; }
        public string Laboratoire { get; set; }
    }
}
